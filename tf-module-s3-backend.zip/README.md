# Introduction 
Terraform module that provision an S3 bucket to store the `terraform.tfstate` file and a DynamoDB table to lock the state file to prevent concurrent modifications and state corruption. 

# Getting Started
Since this is starting point for every Terraform deployment, this is the only module that will keep state file under version control. All other modules should use S3 backend created for this module.

This module also enforces naming convention based on
https://dev.azure.com/orionadvisor/OAT/_wiki/wikis/OAT.wiki/3469/AWS-Resource-Naming-Conventions

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_aws) | ~> 1.0.7 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.60.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 3.60.0 |

# Build and Test

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_naming_conventions"></a> [naming\_conventions](#module\_naming\_conventions) | git::git@ssh.dev.azure.com:v3/orionadvisor/DevOps/tf-module-tagging | v1.0.2 |
| <a name="module_iam_backend_policy"></a> [iam_backend_policy](#module\_iam_backend_policy) | git::git@ssh.dev.azure.com:v3/orionadvisor/DevOps/tf-module-iam-policy | v1.0.0 |
| <a name="module_iam_backend_role"></a> [iam_backend_role](#module\_iam_backend_role) | git::git@ssh.dev.azure.com:v3/orionadvisor/DevOps/tf-module-iam-role | v1.0.0 |

# Resources

| Name | Type |
|------|------|
| [aws_s3_bucket.state_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_public_access_block.bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_dynamodb_table.state_lock](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_region"></a> [region](#input\_region) | Region to deploy resources to. | `string` | `""` | yes |
| <a name="input_env"></a> [env](#input\_env) | Environment name to be built. | `string` | `""` | yes |
| <a name="input_app"></a> [app](#input\_app) | App name to be deployed. | `string` | `""` | yes |
| <a name="input_product"></a> [product](#input\_product) | Product such as queue processor. | `string` | `""` | yes |
| <a name="input_product_area"></a> [product_area](#input\_product_area) | Area such as Orion Connect would encompass queue processor. | `string` | `""` | yes |
| <a name="input_cost_center"></a> [cost_center](#input\_cost_center) | Cost Center ID. | `number` | `0` | yes |
| <a name="input_admin_accounts"></a> [admin_accounts](#input\_admin_accounts) | List of identifiers for principals that will have access to this backend. | `list(string)` | `[]` | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_none"></a> [none](#output\_none) | N/A |


## Work with local state files and Terraform workspaces

Make sure your AWS profile is properly setup with the AWS account you're intended to update (Platform account by default)
```
$ aws configure list
      Name                    Value             Type    Location
      ----                    -----             ----    --------
profile 167223888864_AWSAdministrativeContractors   env    ['AWS_PROFILE', 'AWS_DEFAULT_PROFILE']
access_key     ****************            config-file
secret_key     ****************            config-file
    region                  us-east-1            imds
```
Check current workspace
```
$ terraform workspace list
  default
  platform
* sandbox
```
Choose your workspace
```
$ terraform workspace select platform
Switched to workspace "platform".

$ terraform workspace list
  default
* platform
  sandbox
```

# How to use

Copy the below snippet code, into your terraform configuration files, make necessary adjustments for key value (terraform state location)
```
terraform {  
  backend "s3" {
    region         = "us-east-2"
    bucket         = "sharedservices-use2-s3s-platform"
    key            = "<app>/<tier>/repository/infrastructure.tfstate"
    dynamodb_table = "sharedservices-tf-locks-use2-platform-db"
    role_arn       = "arn:aws:iam::167223888864:role/TerraformBackendRole"
    encrypt        = "true"
  }
}
```
# Contribute
- [GIT repo](https://dev.azure.com/orionadvisor/ITOC/_git/tf-module-s3-backend)

## Authors

Module created 10/28/2021 by Jimmy Molina (jimmy.molina@orion.com).