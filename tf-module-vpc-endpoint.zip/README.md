## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.1 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 4.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 4.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_route53_record.vendor](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_security_group.vpc_endpoints_interface](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.vpc_endpoints_interface_egress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.vpc_endpoints_interface_ingress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_vpc_endpoint.interface](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_endpoint) | resource |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_route53_zone.internal](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cidr_block"></a> [cidr\_block](#input\_cidr\_block) | The CIDR block for the VPC | `string` | `""` | no |
| <a name="input_name"></a> [name](#input\_name) | Name to be used in all `Name` tags shown in the AWS Console | `string` | `""` | no |
| <a name="input_stage"></a> [stage](#input\_stage) | AWS Account name | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | The ID of one or more subnets in which to create a network interface for the endpoint. <br>    Applicable for endpoints of type GatewayLoadBalancer and Interface. | `list(string)` | `[]` | no |
| <a name="input_vendor"></a> [vendor](#input\_vendor) | Keyword identifier for Vendor AWS service endpoint | `string` | `""` | no |
| <a name="input_vpc_endpoints"></a> [vpc\_endpoints](#input\_vpc\_endpoints) | Service name identifiers for the VPC endpoints.<br>  Every VPC endpoint belongs to a service name like `com.amazonaws.REGION.IDENTIFIER`.<br>  The lists of this variable (grouped by VPC endpoint type) are expecting just the `IDENTIFIER` of the service name. | <pre>object({<br>    gateway               = list(string)<br>    interface             = list(string)<br>    gateway-load-balancer = list(string)<br>  })</pre> | <pre>{<br>  "gateway": [],<br>  "gateway-load-balancer": [],<br>  "interface": []<br>}</pre> | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The ID of the VPC in which the endpoint will be used | `string` | `""` | no |

## Outputs

No outputs.
