#!/usr/bin/env python

def main(event, context):
    message = "Hello World"
    print (message)
    return message