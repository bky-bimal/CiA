## Requirements

| Name | Version |
|------|---------|
| terraform | ~> 1.0 |
| aws | ~> 3.0 |

## Resources

| Name | Type |
|------|------|
| ec2_transit_gateway | resource |
| ec2_transit_gateway_route_table | resource |
| ec2_transit_gateway_vpc_attachment | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <_amazon_side_asn | The Autonomous System Number (ASN) for the Amazon side of the gateway. By default the TGW is created with the current default Amazon ASN. | `string` | `"64512"` | no |
| create_tgw | Controls if TGW should be created (it affects almost all resources) | `bool` | `true` | no |
| enable_auto_accept_shared_attachments | Whether resource attachment requests are automatically accepted | `string` | `"enable"` | no |
| enable_default_route_table_association | Whether resource attachments are automatically associated with the default association route table | `string` | `"disable"` | no |
| enable_default_route_table_propagation | Whether resource attachments automatically propagate routes to the default propagation route table | `string` | `"disable"` | no |
| enable_dns_support | Should be true to enable DNS support in the TGW | `string` | `"enable"` | no |
| enable_vpn_ecmp_support | Whether VPN Equal Cost Multipath Protocol support is enabled | `string` | `"enable"` | no |
| route_tables_names | Names of the transit gateway route tables | `list(string)` |  | yes |
| share_tgw | Whether to share your transit gateway with other accounts | `bool` | `true` | no |
| subnet_ids | Identifiers of EC2 Subnets. | `list(string)` |  | yes |
| tags | A map of tags to add to all resources | `map(string)` | `{}` | no |
| transit_gateway_route_table_id | Identifier of EC2 Transit Gateway Route Table to use with the Target Gateway when reusing it between multiple TGWs | `string` | `null` | no |
| vpc_id | Identifier of EC2 VPC. | `string` |  | yes |

## Outputs

| Name | Description |
|------|-------------|
| ec2_transit_gateway_arn | EC2 Transit Gateway Amazon Resource Name (ARN) |
| ec2_transit_gateway_id | EC2 Transit Gateway identifier |