# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<a name="v1.0.2"></a>
## [v1.0.2] - 2021-12-8

- Added dead letter config capability

<a name="v1.0.1"></a>
## [v1.0.1] - 2021-12-8

- Added lambda alias to output

<a name="v1.0.0"></a>
## [v1.0.0] - 2021-10-29

- Initial tf-module-lambda implementation

<a name="v0.0.1"></a>
## v0.0.1 - 2021-10-28

- first commit

[v1.0.0]: https://dev.azure.com/orionadvisor/ITOC/_git/tf-module-lambda/branchCompare?baseVersion=GTv0.0.1&targetVersion=GTv1.0.0&_a=files

[v1.0.1]: https://dev.azure.com/orionadvisor/ITOC/_git/tf-module-lambda/branchCompare?baseVersion=GTv1.0.0&targetVersion=GTv1.0.1&_a=files

[v1.0.2]: https://dev.azure.com/orionadvisor/ITOC/_git/tf-module-lambda/branchCompare?baseVersion=GTv1.0.1&targetVersion=GTv1.0.2&_a=files