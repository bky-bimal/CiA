
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.4 |
| aws | ~> 3.43.0 |

## Providers

| Name | Version |
|------|---------|
| aws | ~> 3.43.0 |

## Basic Usage Example

```hcl
module "ecs-service" {
  source = "git::git@ssh.dev.azure.com:v3/orionadvisor/DevOps/tf-module-ecs-service?ref=v1.1.0"
  name = "my_service"
  cluster_arn = "ecs_cluster_arn"
  task_definition_arn = "task_definition_arn"
  desired_count = 2
  propagate_tags = "TASK_DEFINITION"
  launch_type = "FARGATE"
  health_check_grace_period = 15
  deployment_maximum_percent = 200
  deployment_minimum_percent = 100

  service_registry = {
    arn = "service_discovery_service_arn"
  }
  network_config = {
    subnets = ["subnet_1_id", "subnet_2_id"]
    security_groups = ["security_group_1_id", "security_group_2_id"]
    assign_public_ip = false
  }
  load_balancer = {
    target_group_arn = "alb_target_group_arn"
    container_name = "alb_container_name"
    container_port = 8080
  }
}
```

## Resources

| Name |
|------|
| [aws_ecs_service](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecs_service) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| name | Name to give to the ECS Service. Up to 255 letters (uppercase and lowercase), numbers, underscores, and hyphens are allowed. | `string` | `n/a` | yes |
| cluster\_arn | ARN of the ECS cluster on which to run the service. If a cluster is not specified, the default cluster is assumed. | `string` | `null` | no |
| task\_definition\_arn | Family and revision (family:revision) or full ARN of the task definition to be run in the service. Required unless using the "EXTERNAL" deployment controller. If a revision is not specified, the latest "ACTIVE" revision is used. | `string` | `null` | no |
| desired\_count | Number of instances of the task definition to place and keep running. | `number` | `0` | no |
| propagate\_tags | Specifies whether to propagate the tags from the task definition or the service to the tasks. The valid values are SERVICE and TASK_DEFINITION. | `string` | `"TASK_DEFINITION"` | no |
| launch\_type | Launch type on which to run your service. The valid values are "EC2", "FARGATE", and "EXTERNAL".| `string` | `"FARGATE"` | no |
| health\_check\_grace\_period | Seconds to ignore failing load balancer health checks on newly instantiated tasks to prevent premature shutdown, up to 2147483647. Only valid for services configured to use load balancers. | `number` | `10` | no |
| deployment\_maximum\_percent | (Optional) Upper limit (as a percentage of the service's desiredCount) of the number of running tasks that can be running in a service during a deployment. Not valid when using the DAEMON scheduling strategy. | `number` | `null` | no |
| deployment\_minimum\_percent | (Optional) Lower limit (as a percentage of the service's desiredCount) of the number of running tasks that must remain running and healthy in a service during a deployment. | `number` | `null` | no |
| service\_registry | The details of the service discovery registry to associate with this service. | <pre>object({<br>    arn            = string<br>    port           = optional(number)<br>    container_port = optional(number)<br>    container_name = optional(string)<br>})</pre> | `null` | no |
| network\_config | Network configuration for the service. | <pre>object({<br>    subnets          = list(string)<br>    security_groups  = list(string)<br>    assign_public_ip = optional(bool)<br>})</pre> | `null` | no |
| load\_balancer | Details of the load balancer to be associated to the service. | <pre>object({<br>    target_group_arn = string<br>    container_name   = string<br>    container_port   = number<br>})</pre> | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| output | ECS service object |

## Authors

Module created 9/28/2021 by David Olivas (david.olivas@orion.com).

Module last modified 10/11/2021 by Jimmy Molina (jimmy.molina@orion.com). 