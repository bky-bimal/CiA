# Terraform Elasticache Redis module

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.4 |
| aws | >= 3.64.2 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 3.64.2 |
| random | n/a |

## Basic usage example

```
module "redis" {
  source      = "../"
  name        = "test"
  vpc_id      = "vpc-07c3b40c85aec2bea"
  subnet_ids  = ["subnet-067717a2b9b0599df", "subnet-0bad8a6433ac4a790"]
  application = "eclipse"
  environment = "dev"
}
```

## Resources

| Name |
|------|
| [aws_elasticache_parameter_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/elasticache_parameter_group) |
| [aws_elasticache_replication_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/elasticache_replication_group) |
| [aws_elasticache_subnet_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/elasticache_subnet_group) |
| [aws_security_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) |
| [aws_security_group_rule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) |
| [random_id](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| allowed\_cidr\_blocks | A list of CIDR blocks which are allowed to access the database | `list(string)` | `[]` | no |
| allowed\_security\_groups | One or more VPC security groups associated with the cache cluster | `list(string)` | `[]` | no |
| application | The application that the cache belongs to. | `string` | n/a | yes |
| apply\_immediately | Specifies whether any database modifications are applied immediately, or during the next maintenance window | `bool` | `false` | no |
| at\_rest\_encryption\_enabled | Whether to enable encryption at rest | `bool` | `true` | no |
| auth\_token | Password used to access a password protected server. Can be specified only if transit_encryption_enabled = true. | `secure string` | `null` | no |
| automatic\_failover\_enabled | Specifies whether a read-only replica will be automatically promoted to read/write primary if the existing primary fails | `bool` | `true` | no |
| cache\_parameters | A list of maps containing the DB parameters to apply (depends on the family) | <pre>list(object({<br>    name  = string <br>    value = string<br>  }))</pre> | `[]` | no |
| engine\_version | Version number of the cache engine to be used, you can retrieve the versions available with: aws elasticache describe-cache-engine-versions. When engine is redis and the version is 6 or higher, only the major version can be set, e.g., 6.x, otherwise, specify the full version desired, e.g., 5.0.6. | `string` | `"6.x"` | no |
| environment | The environment where you want to create the resources | `string` | n/a | yes |
| instance\_class | The instance class to be used. | `string` | `"cache.t3.small"` | no |
| kms\_key\_id | The ARN of the key that you wish to use if encrypting at rest. If not supplied, uses service managed encryption. | `string` | `null` | no |
| maintenance\_window | Specifies the weekly time range for when maintenance on the cache cluster is performed. The format is ddd:hh24:mi-ddd:hh24:mi (24H Clock UTC) | `string` | `"sun:05:00-sun:09:00"` | no |
| multi\_az\_enabled | Specifies whether to enable Multi-AZ Support for the replication group. If true, automatic_failover_enabled must also be enabled. | `bool` | `true` | no |
| name | The name of the cluster, group identifier. ElastiCache converts this name to lowercase | `string` | n/a | yes |
| num\_node\_groups | Specify the number of node groups (shards) for this Redis replication group. Changing this number will trigger an online resizing operation before other settings modifications. | `number` | `1` | no |
| port | The port number on which each of the cache nodes will accept connections. | `number` | `6379` | no |
| replicas\_per\_node\_group | Specify the number of replica nodes in each node group. Valid values are 0 to 5. Changing this number will force a new resource | `number` | `1` | no |
| snapshot\_arns | Single-element string list containing an Amazon Resource Name (ARN) of a Redis RDB snapshot file stored in Amazon S3 | `list(string)` | `null` | no |
| snapshot\_name | The name of a snapshot from which to restore data into the new node group. Changing the snapshot\_name forces a new resource | `string` | `null` | no |
| snapshot\_retention\_limit | The number of days for which ElastiCache will retain automatic cache cluster snapshots before deleting them. For example, if you set SnapshotRetentionLimit to 5, then a snapshot that was taken today will be retained for 5 days before being deleted. If the value of SnapshotRetentionLimit is set to zero (0), backups are turned | `number` | `7` | no |
| snapshot\_window | The daily time range (in UTC) during which ElastiCache will begin taking a daily snapshot of your cache cluster | `string` | `null` | no |
| subnet\_group\_name | The name of the subnet group name (existing) | `string` | `""` | no |
| subnet\_ids | A list of subnets that are going to be used for the subnet group | `list(string)` | `[]` | no |
| tags | A map of tags to add to all resources | `map(string)` | `{}` | no |
| transit\_encryption\_enabled | Whether to enable encryption in transit | `bool` | `false` | no |
| vpc\_id | The id of the VPC that is going to be used for the security group | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| output | Cluster and security group attributes |