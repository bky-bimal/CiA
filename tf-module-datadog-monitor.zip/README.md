## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.43.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 3.43.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Basic usage example 

```hcl
locals {
resource "datadog_monitor" "dd_monitor" {
  name               = test_monitor
  type               = type
  message            = "threshold reached" 
  escalation_message = "message"

  query = "string query from datadog"

  monitor_thresholds {
    warning           = monitor
    warning_recovery  = recovery
    critical          = critical
    critical_recovery = critical_recovery
  }

  notify_no_data    = ""
  renotify_interval = "5"

  notify_audit = ""
  timeout_h    = 100
  include_tags = ""

  tags = "test"
}
}
```

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
|[monitor]](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |



## Inputs

All inputs are REQUIRED.

| Name | Description | Type |
|------|-------------|------|
| datadog\_monitor\_name | Name of the Datadog monitor | `string` | 
| datadog\_monitor\_type | Type of the Datadog monitor and cannot be changed after created. Valid values are composite, event alert, log alert, metric alert, process alert, query alert, rum alert, service check, synthetics alert, trace-analytics alert, slo alert, event-v2 alert, audit alert | `string` |
| datadog\_monitor\_message | A message to include with notifications | `string` |
| datadog\_monitor\_escalation\_message | A message to include with a re-notification and also supports the @username notification allowed elsewhere | `string` |
| warning\_monitor | The monitor WARNING threshold. Must be a number | `string` |
| wargning\_recovery\_monitor | The monitor WARNING recovery threshold. Must be a number | `string` |
| critical\_monitor | The monitor CRITICAL threshold. Must be a number | `string` |
| critical\_recovery\_monitor | The monitor CRITICAL recovery threshold. Must be a number | `string` |
| monitor\_notify\_no\_data |A boolean indicating whether this monitor will notify when data stops reporting | `bool` |
| monitor\_renotify\_interval | The number of minutes after the last notification before a monitor will re-notify on the current status. It will only re-notify if it's not resolved | `number` |
| monitor\_notify\_audit | A boolean indicating whether tagged users will be notified on changes to this monitor | `bool` |
| monitor\_timeout | The number of hours of the monitor not reporting data before it will automatically resolve from a triggered state | `number` |
| monitor\_include\_tags | A boolean indicating whether notifications from this monitor automatically insert its triggering tags into the title | `bool` |
| monitor\_tags | A list of tags to associate with your monitor | `list(string)` |
| query | Query pulled from Datadog | `string` |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_output"></a> [output](#output\_output) |