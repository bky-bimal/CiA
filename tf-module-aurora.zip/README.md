# Terraform Aurora RDS Module

## Example basic usage
```
module "rds" {
  source                  = "aurora/"
  name                    = "firm"
  vpc_id                  = "vpc-07c3b40c85aec2bea"
  subnet_ids              = ["subnet-067717a2b9b0599df", "subnet-0bad8a6433ac4a790"]
  application             = "eclipse"
  environment             = "dev"
  cluster_instances_count = 2
}

```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.4 |
| aws | >= 3.64.2 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 3.64.2 |
| random | n/a |


## Resources

| Name |
|------|
| [aws_appautoscaling_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/appautoscaling_policy) |
| [aws_appautoscaling_target](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/appautoscaling_target) |
| [aws_db_subnet_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/db_subnet_group) |
| [aws_iam_policy_document](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) |
| [aws_iam_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) |
| [aws_rds_cluster](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/rds_cluster) |
| [aws_rds_cluster_instance](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/rds_cluster_instance) |
| [aws_rds_cluster_role_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/rds_cluster_role_association) |
| [aws_security_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) |
| [aws_security_group_rule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) |
| [aws_ssm_parameter](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) |
| [random_id](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) |
| [random_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| allow\_major\_version\_upgrade | Enable to allow major engine version upgrades when changing engine versions. Defaults to `false` | `bool` | `false` | no |
| allowed\_cidr\_blocks | A list of CIDR blocks which are allowed to access the database | `list(string)` | `[]` | no |
| application | Name of the application that the database belongs to. | `string` | n/a | yes |
| apply\_immediately | Specifies whether any cluster modifications are applied immediately, or during the next maintenance window. Default is `false` | `bool` | `null` | no |
| autoscaling\_enabled | Determines whether autoscaling of the cluster read replicas is enabled | `bool` | `false` | no |
| autoscaling\_max\_capacity | Maximum number of read replicas permitted when autoscaling is enabled | `number` | `2` | no |
| autoscaling\_min\_capacity | Minimum number of read replicas permitted when autoscaling is enabled | `number` | `0` | no |
| autoscaling\_scale\_in\_cooldown | Cooldown in seconds before allowing further scaling operations after a scale in | `number` | `300` | no |
| autoscaling\_scale\_out\_cooldown | Cooldown in seconds before allowing further scaling operations after a scale out | `number` | `300` | no |
| autoscaling\_target\_connections | Average number of connections threshold which will initiate autoscaling. Default value is 70% of db.r4/r5/r6g.large's default max\_connections | `number` | `700` | no |
| autoscaling\_target\_cpu | CPU threshold which will initiate autoscaling | `number` | `70` | no |
| backtrack\_window | The target backtrack window, in seconds. Only available for `aurora` engine currently. To disable backtracking, set this value to 0. Must be between 0 and 259200 (72 hours) | `number` | `null` | no |
| backup\_retention\_period | The days to retain backups for. Default `14` | `number` | `14` | no |
| cluster\_instances\_count | Count of rds cluster instances to create | `number` | `1` | no |
| cluster\_timeouts | Create, update, and delete timeout configurations for the cluster | `map(string)` | `{}` | no |
| copy\_tags\_to\_snapshot | Copy all Cluster `tags` to snapshots | `bool` | `null` | no |
| database\_name | Name for an automatically created database on cluster creation | `string` | `null` | no |
| db\_cluster\_parameter\_group\_name | A cluster parameter group to associate with the cluster | `string` | `null` | no |
| db\_instance\_parameter\_group\_name | Instance parameter group to associate with all instances of the DB cluster. The `db_cluster_db_instance_parameter_group_name` is only valid in combination with `allow_major_version_upgrade` | `string` | `null` | no |
| db\_subnet\_group\_name | The name of the subnet group name (existing) | `string` | `""` | no |
| deletion\_protection | If the DB instance should have deletion protection enabled. The database can't be deleted when this value is set to `true`. The default is `false` | `bool` | `true` | no |
| enable\_global\_write\_forwarding | Whether cluster should forward writes to an associated global cluster. Applied to secondary clusters to enable them to forward writes to an `aws_rds_global_cluster`'s primary cluster | `bool` | `null` | no |
| enable\_http\_endpoint | Enable HTTP endpoint (data API). Only valid when engine\_mode is set to `serverless` | `bool` | `null` | no |
| enabled\_cloudwatch\_logs\_exports | Set of log types to export to cloudwatch. If omitted, no logs will be exported. The following log types are supported: `audit`, `error`, `general`, `slowquery`, `postgresql` | `list(string)` | `[]` | no |
| engine | The name of the database engine to be used for this DB cluster. Defaults to `aurora`. Valid Values: `aurora`, `aurora-mysql`, `aurora-postgresql` | `string` | `null` | no |
| engine\_mode | The database engine mode. Valid values: `global`, `multimaster`, `parallelquery`, `provisioned`, `serverless`. Defaults to: `provisioned` | `string` | `null` | no |
| engine\_version | The database engine version. Updating this argument results in an outage | `string` | `null` | no |
| environment | An environment name used in the resource name creation. I.e. prod, dev, test, etc | `string` | n/a | yes |
| global\_cluster\_identifier | The global cluster identifier specified on `aws_rds_global_cluster` | `string` | `null` | no |
| iam\_database\_authentication\_enabled | Specifies whether or mappings of AWS Identity and Access Management (IAM) accounts to database accounts is enabled | `bool` | `null` | no |
| iam\_roles | Map of IAM roles and supported feature names to associate with the cluster | <pre>list(object({<br>    role_arn     = string<br>    feature_name = string<br>  }))</pre> | `[]` | no |
| instance\_class | Instance type to use at master instance. Note: if `autoscaling_enabled` is `true`, this will be the same instance class used on instances created by autoscaling | `string` | `"db.t3.small"` | no |
| is\_primary\_cluster | Determines whether cluster is primary cluster with writer instance (set to `false` for global cluster and replica clusters) | `bool` | `true` | no |
| kms\_key\_arn | The ARN for the KMS encryption key. | `string` | `null` | no |
| master\_username | Username for the master DB user | `string` | `"root"` | no |
| monitoring\_interval | The interval, in seconds, between points when Enhanced Monitoring metrics are collected for instances. Set to `0` to disble. Default is `0` | `number` | `0` | no |
| name | Name used across resources created | `string` | n/a | yes |
| port | The port on which the DB accepts connections | `string` | `null` | no |
| predefined\_metric\_type | The metric type to scale on. Valid values are `RDSReaderAverageCPUUtilization` and `RDSReaderAverageDatabaseConnections` | `string` | `"RDSReaderAverageCPUUtilization"` | no |
| preferred\_backup\_window | The daily time range during which automated backups are created if automated backups are enabled using the `backup_retention_period` parameter. Time in UTC | `string` | `"02:00-03:00"` | no |
| preferred\_maintenance\_window | The weekly time range during which system maintenance can occur, in (UTC) | `string` | `"sun:05:00-sun:06:00"` | no |
| random\_password\_length | Length of random password to create. | `number` | `16` | no |
| replication\_source\_identifier | ARN of a source DB cluster or DB instance if this DB cluster is to be created as a Read Replica | `string` | `null` | no |
| restore\_to\_point\_in\_time | Map of nested attributes for cloning Aurora cluster | `map(string)` | `null` | no |
| s3\_import | Configuration map used to restore from a Percona Xtrabackup in S3 (only MySQL is supported) | `map(string)` | `null` | no |
| scaling\_configuration | Map of nested attributes with scaling properties. Only valid when `engine_mode` is set to `serverless` | `map(string)` | `{}` | no |
| security\_group\_ids | List of VPC security groups to associate to the cluster in addition to the SG we create in this module | `list(string)` | `[]` | no |
| skip\_final\_snapshot | Determines whether a final snapshot is created before the cluster is deleted. If true is specified, no snapshot is created | `bool` | `null` | no |
| snapshot\_identifier | Specifies whether or not to create this cluster from a snapshot. You can use either the name or ARN when specifying a DB cluster snapshot, or the ARN when specifying a DB snapshot | `string` | `null` | no |
| source\_region | The source region for an encrypted replica DB cluster | `string` | `null` | no |
| subnet\_ids | List of subnet IDs used by database subnet group created | `list(string)` | `[]` | no |
| tags | A map of tags to add to all resources | `map(string)` | `{}` | no |
| vpc\_id | ID of the VPC where to create security group | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| output | n/a |
