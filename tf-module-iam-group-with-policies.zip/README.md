# This module creates a group named after the "name" variable intended to contain IAM users defined in the "group_users".
## Basic usage example for administering IAM group resources

```hcl

module "iam_group_with_policies" {
  source = "./module/iam-group-with-policies"

  name                     = "test-users-group-3"
  group_users              = [module.iam_user.output.user]
  custom_group_policy_arns = ["arn:aws:iam::aws:policy/AmazonEC2FullAccess", "arn:aws:iam::aws:policy/CloudWatchActionsEC2Access"]
}

```
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.5 |
| aws | >= 3.56.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 3.56.0 |

## Resources

| Name |
|------|
| [aws_iam_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_group) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| custom\_group\_policy\_arns | List of IAM policies ARNs to attach to IAM group. | `list(string)` | `[]` | no |
| group\_users | List of IAM users to have in an IAM group which can assume the role. | `list(string)` | `[]` | no |
| name | Desired name for the IAM group. | `string` | `""` | yes |
| path | Desired path for the IAM group. | `string` | `"/"` | no |

## Outputs

| Name | Description |
|------|-------------|
| output | IAM group attributees |

## Authors

Module created by Jimmy Molina (jimmy.molina@orion.com).