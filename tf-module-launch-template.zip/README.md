## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.3 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.43.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 3.70.0 |

## Basic usage example 
Create Basic Launch Template with AMI based root volume.
```hcl
module "lt" {
  source       = "../modules/launch_template"
  name_prefix  = "testing-lt-yay"
  image_id     = "ami-0369e9392602c36a1"
  instance_type = "t3a.2xlarge"
}
```
## Advanced useage example
Creates launch template with encrypted volume with custom KMS Key for EBS volumes. (Key Policy ommited)

```hcl
provider "aws" {
  region = "us-east-2"
}

module "aws_kms_key" {
  source = "../../../modules/kms"
  description             = "Testing"
  is_enabled                 = true
  deletion_window_in_days = 30
  kms_alias = "testing_ebs"
}

module "lt" {
  source       = "../../../modules/launch_template"
  name_prefix  = "testing-lt-yay"
  image_id     = "ami-0369e9392602c36a1"
  instance_type = "t3a.2xlarge"
  block_device_mappings = [{
    device_name = "/dev/sda1"
    ebs = {
      volume_size = 80
      encrypted = true
      kms_key_id = module.aws_kms_key.output.kms.key_id
    }
  }]
}
```

## Resources

| Name | Type |
|------|------|
| [aws_launch_template.launch_template](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/launch_template) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_service"></a> [application\_service](#input\_application\_service) | An application name or service name used in the resource name creation. I.e. orionconnect, oasremote, etc | `string` | n/a | yes |
| <a name="input_associate_public_ip_address"></a> [associate\_public\_ip\_address](#input\_associate\_public\_ip\_address) | Association of Public IP in the Public subnet | `bool` | `false` | no |
| <a name="input_block_device_mappings"></a> [block\_device\_mappings](#input\_block\_device\_mappings) | Specify volumes to attach to the instance besides the volumes specified by the AMI | <pre>list(object({<br>    device_name  = optional(string)<br>    no_device    = optional(bool)<br>    virtual_name = optional(string)<br>    ebs = object({<br>      delete_on_termination = optional(bool)<br>      encrypted             = bool<br>      iops                  = optional(number)<br>      kms_key_id            = optional(string)<br>      snapshot_id           = optional(string)<br>      volume_size           = number<br>      volume_type           = optional(string)<br>    })<br>  }))</pre> | `[]` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | An environment name used in the resource name creation. I.e. prod, dev, test, etc | `string` | n/a | yes |
| <a name="input_iam_instance_profile"></a> [iam\_instance\_profile](#input\_iam\_instance\_profile) | Instance Profile Name | `string` | `null` | no |
| <a name="input_image_id"></a> [image\_id](#input\_image\_id) | AMI ID - Use a Data resource object to fetch. | `string` | n/a | yes |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | Base instance type to utilize | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Region for the resource creation. This value is used for create the availability zone abbreviation | `string` | n/a | yes |
| <a name="input_resource_tags"></a> [resource\_tags](#input\_resource\_tags) | The tags to apply to the resources during launch. | `map(string)` | `null` | no |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | List of vpc sg Ids to associate the LT | `list(string)` | n/a | yes |
| <a name="input_separator"></a> [separator](#input\_separator) | Separator to separate words in resource name (default '-') | `string` | `"-"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map of tags to assign to the resource. | `map(any)` | `{}` | no |
| <a name="input_user_data"></a> [user\_data](#input\_user\_data) | UserData - String based | `string` | `""` | no |
| <a name="resource_tags_types"></a> [resource\_tags\_types](#input\_resource\_tags\_types) | List of resource types to apply resource tags to within the launch template | `list(string)` | `["instance", "volume", "network-interface"]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_launch_template"></a> [launch\_template](#output\_launch\_template) | Launch Template Object |
