# This Terraform module creates an AWS ECS task definition.

## Basic usage example for creating revision of an ECS task definition to be used in ECS service

```hcl

module "ecs_task_definition" {
  source                = "git::https://orionadvisor@dev.azure.com/orionadvisor/DevOps/_git/tf-module-ecs-task-definition?ref=v1.0.0"

  name_prefix           = "test"
  container_definitions = "[${module.ecs_container_definition.json_map_encoded}]"
  task_execution_role   = "arn:aws:iam::173279463787:role/ecsTaskExecutionRole"
}

```
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.7 |
| aws | ~> 3.60.0 |

## Providers

| Name | Version |
|------|---------|
| aws | ~> 3.60.0 |

## Resources

| Name |
|------|
| [aws_ecs_task_definition](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecs_task_definition) |
| [lookup](https://www.terraform.io/docs/language/functions/lookup.html) |
| [dynamic-blocks](https://www.terraform.io/docs/language/expressions/dynamic-blocks.html) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| name\_prefix | A unique name for your task definition. | `string` | ` ` | yes |
| container\_definitions | A list of valid container definitions provided as a single valid JSON document. | `string` | ` ` | yes |
| task\_role\_arn | (Optional) ARN of IAM role that allows your Amazon ECS container task to make calls to other AWS services. | `string` | `null` | no |
| task_execution_role | (Optional) ARN of the task execution role that the Amazon ECS container agent and the Docker daemon can assume. | `string` | `null` | no |
| placement\_constraints | (Optional) Configuration block for rules that are taken into consideration during task placement. Maximum number of placement_constraints is 10. This is a list of maps, where each map should contain `"type"` and `"expression"`. | `list(any)` | `[]` | no |
| task\_cpu | (Optional) Number of cpu units used by the task. If the requires_compatibilities is FARGATE this field is required. | `number` | `1024` | no |
| task\_memory | (Optional) Amount (in MiB) of memory used by the task. If the requires_compatibilities is FARGATE this field is required. | `number` | `4096` | no |
| proxy\_configuration | (Optional) Configuration block for the App Mesh proxy. | `list(any)` | `[]` | no |
| volumes | (Optional) Configuration block for volumes that containers in your task may use. | `list(object({}))` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| output | Full Object of the Task Definition (including arn, family and revision). |

## Authors

Module created by Jimmy Molina (jimmy.molina@orion.com).