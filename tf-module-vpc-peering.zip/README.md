## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws.acceptor"></a> [aws.acceptor](#provider\_aws.acceptor) | ~> 3.0 |
| <a name="provider_aws.requester"></a> [aws.requester](#provider\_aws.requester) | ~> 3.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_route.acceptor_private_peer_route](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route) | resource |
| [aws_route.requester_data_peer_route](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route) | resource |
| [aws_route.requester_private_peer_route](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route) | resource |
| [aws_vpc_peering_connection.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_peering_connection) | resource |
| [aws_vpc_peering_connection_accepter.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_peering_connection_accepter) | resource |
| [aws_caller_identity.acceptor_peer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_route_tables.acceptor_peer_private_rt](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route_tables) | data source |
| [aws_route_tables.acceptor_peer_public_rt](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route_tables) | data source |
| [aws_route_tables.requester_data_rt](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route_tables) | data source |
| [aws_route_tables.requester_private_rt](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route_tables) | data source |
| [aws_vpc.acceptor_peer_vpc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |
| [aws_vpc.requester_peer_vpc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_acceptor_peer_vpc_id"></a> [acceptor\_peer\_vpc\_id](#input\_acceptor\_peer\_vpc\_id) | Peering VPC ID | `string` | `""` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment to deployment | `string` | `"shared-services"` | no |
| <a name="input_is_enable_acceptor_public_routes"></a> [is\_enable\_acceptor\_public\_routes](#input\_is\_enable\_acceptor\_public\_routes) | Feature Flag to enable acceptor public routes back to requester | `bool` | `false` | no |
| <a name="input_is_enabled"></a> [is\_enabled](#input\_is\_enabled) | Feature Flag to enable VPC Peering. Providers are REQUIRED to be passed regardless. | `bool` | `false` | no |
| <a name="input_peering_name"></a> [peering\_name](#input\_peering\_name) | VPC Peering Link Name. Refer to naming standards | `string` | `""` | no |
| <a name="input_region"></a> [region](#input\_region) | Deployment Region | `string` | `"us-east-1"` | no |
| <a name="input_requester_vpc_id"></a> [requester\_vpc\_id](#input\_requester\_vpc\_id) | Requester VPC ID | `string` | `""` | no |

## Outputs

No outputs.

## Example
```terraform
provider "aws" {
  alias  = "requester"
  region = "us-east-1"
}

provider "aws" {
  alias  = "acceptor"
  region = "us-east-1"
  assume_role {
    role_arn = "arn:aws:iam::173279463787:role/pulumi-iam-role"
  }
}

module "peer" {
  source               = "peer"
  providers            = {
    aws.requester = aws.requester
    aws.acceptor  = aws.acceptor
  }
  peering_name                     = "testing"
  is_enabled                       = true
  is_enable_acceptor_public_routes = true
  requester_vpc_id                 = "vpc-123"
  acceptor_peer_vpc_id             = "vpc-456"
  peering_name                     = "legacy_nonprod_to_review"
}
```