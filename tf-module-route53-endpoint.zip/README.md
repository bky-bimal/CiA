# README.md

Module to create DNS resolver endpoints and forwarding rules.

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 4.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 4.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ram_principal_association.endpoint_ram_principal](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ram_principal_association) | resource |
| [aws_ram_resource_association.endpoint_ram_resource](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ram_resource_association) | resource |
| [aws_ram_resource_share.endpoint_rule_sharing](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ram_resource_share) | resource |
| [aws_route53_resolver_endpoint.resolver_endpoint_inbound](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_resolver_endpoint) | resource |
| [aws_route53_resolver_endpoint.resolver_endpoint_outbound](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_resolver_endpoint) | resource |
| [aws_route53_resolver_rule.fwd](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_resolver_rule) | resource |
| [aws_route53_resolver_rule_association.fwdrule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_resolver_rule_association) | resource |
| [aws_security_group.r53_endpoint_sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.endpoint_dns_tcp_egress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.endpoint_dns_tcp_ingress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.endpoint_dns_udp_egress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.endpoint_dns_udp_ingress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_organizations_organization.org](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/organizations_organization) | data source |
| [aws_subnet.selected](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allowed_egress_resolvers"></a> [allowed\_egress\_resolvers](#input\_allowed\_egress\_resolvers) | The list of allowed outbound CIDRs | `list(string)` | n/a | yes |
| <a name="input_allowed_ingress_resolvers"></a> [allowed\_ingress\_resolvers](#input\_allowed\_ingress\_resolvers) | The list of allowed inbound CIDRs | `list(string)` | n/a | yes |
| <a name="input_azs"></a> [azs](#input\_azs) | The list of azs to provision the resolver endpoint in | `any` | n/a | yes |
| <a name="input_dns_port"></a> [dns\_port](#input\_dns\_port) | The Resolver Endpoint DNS port number | `any` | n/a | yes |
| <a name="input_inbound_endpoint"></a> [inbound\_endpoint](#input\_inbound\_endpoint) | Whether to create the resolver inbound endpoint or not | `any` | n/a | yes |
| <a name="input_outbound_endpoint"></a> [outbound\_endpoint](#input\_outbound\_endpoint) | Whether to create the resolver outbound endpoint or not | `any` | n/a | yes |
| <a name="input_r53_name"></a> [r53\_name](#input\_r53\_name) | The name of the endpoint | `any` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The region to provision resources in | `any` | n/a | yes |
| <a name="input_resolver_rules"></a> [resolver\_rules](#input\_resolver\_rules) | The parameters for the  forwarding rules | `map(any)` | n/a | yes |
| <a name="input_subnet_names"></a> [subnet\_names](#input\_subnet\_names) | The prefix of the subnet names to fetch subnet ID using data source | `any` | n/a | yes |
| <a name="input_tag_name"></a> [tag\_name](#input\_tag\_name) | The tag name of the endpoint | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_inbound_endpoint_id"></a> [inbound\_endpoint\_id](#output\_inbound\_endpoint\_id) | Resolver endpoint ID |
| <a name="output_outbound_endpoint_id"></a> [outbound\_endpoint\_id](#output\_outbound\_endpoint\_id) | Resolver endpoint ID |
| <a name="output_security_group_id"></a> [security\_group\_id](#output\_security\_group\_id) | Resolver endpoint security group ID |
