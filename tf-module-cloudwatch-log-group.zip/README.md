# Terraform module to create an AWS Cloudwatch log group

## Basic usage example for administering Cloudwatch log group resources

```hcl

module "cloudwatch_log_group" {
  source = "./modules/cloudwatch-log-group"

  application_service        = "orionconnect"
  region                     = "us-east-1"
  environment                = "dev"
  name_suffix                = "test-group"
  tags = {
    Description = "Cloud Watch test group"
  }
}

```
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.5 |
| aws | >= 3.56.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 3.56.0 |

## Resources

| Name |
|------|
| [aws_cloudwatch_log_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| retention\_days | Specifies the number of days you want to retain log events in the specified log group. | `number` | `14` | no |
| tags | A map of tags to add to the resources. | `map(string)` | `{}` | no |
| application_service | An application name or service name used in the resource name creation. I.e. orionconnect, oasremote, etc. | `string` | n/a | yes |
| region | Region for the resource creation. This value is used for create the region zone abbreviation. | `string` | n/a | yes |
| environment | An environment name used in the resource name creation. I.e. prod, dev, test, etc. | `string` | n/a | yes |
| separator | Separator to separate words in resource name (default '-'). | `string` | `-` | yes |


## Outputs

| Name | Description |
|------|-------------|
| output | CloudWatch log group attributees |

## Authors

Module created by Jimmy Molina (jimmy.molina@orion.com).