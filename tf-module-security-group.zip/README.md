## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 4.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 4.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_security_group.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.rule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_service"></a> [application\_service](#input\_application\_service) | An application name or service name used in the resource name creation. I.e. orionconnect, oasremote, etc | `string` | n/a | yes |
| <a name="input_customer"></a> [customer](#input\_customer) | A customer name used in the resource name creation. I.e. orion | `string` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | Description for the security group | `string` | `"Created by terraform"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | An environment name used in the resource name creation. I.e. prod, dev, test, etc | `string` | n/a | yes |
| <a name="input_resource_type"></a> [resource\_type](#input\_resource\_type) | The name of the resource type that the security group will use, this is used in the creation of the resource name. I.e. ec2, alb, etc | `string` | n/a | yes |
| <a name="input_rules"></a> [rules](#input\_rules) | Ingress/Egress rules to apply to the security group | <pre>list(object({<br>    type                     = string<br>    from_port                = number<br>    to_port                  = number<br>    protocol                 = string<br>    self                     = optional(bool)<br>    description              = optional(string)<br>    cidr_blocks              = optional(list(string))<br>    prefix_list_ids          = optional(list(string))<br>    source_security_group_id = optional(string)<br>  }))</pre> | `[]` | no |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | Suffix to add to the security group name (default 'sg') | `string` | `"sg"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map of tags to assign to the resource. | `map(any)` | `{}` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | Id of the vpc where the security group will be created | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_security_group"></a> [security\_group](#output\_security\_group) | Security group object |
