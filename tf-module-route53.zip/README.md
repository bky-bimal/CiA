## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.13.4 |
| aws | >= 3.43.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 3.43.0 |

## Example Usage

```hcl
module "route53" {
  source        = "./modules/route53"
  zone_id       = "Z1234556778"
  name          = "test.orion.com"
  type          = "A"
  records       = ["172.10.0.1"]
}
```

## Resources

| Name |
|------|
| [aws_route53_record](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| alias\_name | DNS domain name for a CloudFront distribution, S3 bucket, ELB, or another resource record set in this hosted zone. | `string` | `null` | no |
| alias\_target\_health | Set to true if you want Route 53 to determine whether to respond to DNS queries using this resource record set by checking the health of the resource record set | `bool` | `false` | no |
| alias\_zone\_id | Hosted zone ID for a CloudFront distribution, S3 bucket, ELB, or Route 53 hosted zone. See resource\_elb.zone\_id for example. | `string` | `null` | no |
| name | The name of the record. | `any` | n/a | yes |
| records | A string list of records | `list(string)` | `[]` | no |
| ttl | The TTL of the record. | `string` | `"60"` | no |
| type | The record type. Valid values are A, AAAA, CAA, CNAME, DS, MX, NAPTR, NS, PTR, SOA, SPF, SRV and TXT. | `string` | `"A"` | no |
| zone\_id | The ID of the hosted zone to contain this record. | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| output | Route53 record object |

## Authors

Module created by Bryan Hernandez.
