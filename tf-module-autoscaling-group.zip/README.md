## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.43.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 3.43.0 |

## Basic Usage example

```hcl

module "asg"{
    source                      =  ".."
    name__prefix                =  "asg_name"
    max_size                    =  3
    min_size                    =  1
    launch_configuration_name   =  "launch_configuration_name"
    application_service         =  "orionconnect"
    region                      =  "us-east-1"
    environment                 =  "dev"
}
```

## Resources

| Name | Type |
|------|------|
| [aws_autoscaling_group.asg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_service"></a> [application\_service](#input\_application\_service) | An application name or service name used in the resource name creation. I.e. orionconnect, oasremote, etc | `string` | n/a | yes |
| <a name="input_default_cooldown"></a> [default\_cooldown](#input\_default\_cooldown) | (Optional) Time after a scaling activity completes before another scaling activity can start | `number` | `300` | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | (Optional) The number of Amazon EC2 instances that should be running in the group. | `number` | `1` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | An environment name used in the resource name creation. I.e. prod, dev, test, etc | `string` | n/a | yes |
| <a name="input_force_delete"></a> [force\_delete](#input\_force\_delete) | (Optional) Allows deleting the autoscaling group without waiting for all instances in the pool to terminate. | `bool` | `false` | no |
| <a name="input_health_check_grace_period"></a> [health\_check\_grace\_period](#input\_health\_check\_grace\_period) | (Optional) Time after instance comes into service before checking health. | `number` | `300` | no |
| <a name="input_health_check_type"></a> [health\_check\_type](#input\_health\_check\_type) | (Optional) Controls how health checking is done (EC2 or ELB). | `string` | `""` | no |
| <a name="input_instance_refresh"></a> [instance\_refresh](#input\_instance\_refresh) | (Optional) Enable the [instance refresh](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_group#instance_refresh) feature of Autoscaling Groups using the default [settings](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_group#instance_refresh). If omitted, instance refresh will be turned off. | <pre>object({<br>  strategy = string<br>})</pre> | `{}` | no |
| <a name="input_instances_distribution"></a> [instances\_distribution](#input\_instances\_distribution) | Settings on how to mix on-demand and Spot instances in the Auto Scaling group. | <pre>object({<br>    spot_max_price                           = optional(string)<br>    spot_instance_pools                      = optional(number)<br>    on_demand_base_capacity                  = optional(number)<br>    spot_allocation_strategy                 = optional(string)<br>    on_demand_allocation_strategy            = optional(string)<br>    on_demand_percentage_above_base_capacity = optional(number)<br>  })</pre> | `null` | no |
| <a name="input_launch_configuration_name"></a> [launch\_configuration\_name](#input\_launch\_configuration\_name) | The name of the launch configuration resource to be used when launch the ASG. | `string` | `null` | no |
| <a name="input_launch_template_id"></a> [launch\_template\_id](#input\_launch\_template\_id) | The ID of the launch template to reference. | `string` | `null` | no |
| <a name="input_launch_template_overrides"></a> [launch\_template\_overrides](#input\_launch\_template\_overrides) | Provides the ability to specify multiple instance types, takes the first element instance\_type with plain launch template. | `list(map(string))` | `null` | no |
| <a name="input_launch_template_version"></a> [launch\_template\_version](#input\_launch\_template\_version) | Version of the launch template to use in the ASG resource. | `string` | `$Latest` | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | The created ASG will have this number of instances at maximum. | `number` | n/a | yes |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | The created ASG will have this number of instances at minimum. | `number` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Region for the resource creation. This value is used for create the availability zone abbreviation | `string` | n/a | yes |
| <a name="input_separator"></a> [separator](#input\_separator) | Separator to separate words in resource name (default '-') | `string` | `"-"` | no |
| <a name="input_subnets_ids"></a> [subnets\_ids](#input\_subnets\_ids) | (Optional) A list of subnet IDs to launch resources in. | `list(any)` | `[]` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to assing to the ASG | `map(any)` | `{}` | no |
| <a name="input_target_group_arns"></a> [target\_group\_arns](#input\_target\_group\_arns) | (Optional) A list of target group ARNs, for use with Application or Network Load Balancing. | `list(any)` | `[]` | no |
| <a name="input_wait_for_capacity_timeout"></a> [wait\_for\_capacity\_timeout](#input\_wait\_for\_capacity\_timeout) | (Optional) A maximum duration that Terraform should wait for ASG instances to be healthy before timing out. | `string` | `"10m"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_output"></a> [output](#output\_output) | ASG object |
